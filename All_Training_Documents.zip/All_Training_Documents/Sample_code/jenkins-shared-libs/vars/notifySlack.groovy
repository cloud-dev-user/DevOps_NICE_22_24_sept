def call(String message, String color = '#00FF00') {
    slackSend(channel: '#jenkins', color: color, message: message)
}