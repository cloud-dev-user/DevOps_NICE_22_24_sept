def call(String goals = 'clean install -DskipTests') {
    stage('Maven Build') {
        echo "Executing: mvn ${goals}"
        sh "mvn ${goals}"
    }
}
