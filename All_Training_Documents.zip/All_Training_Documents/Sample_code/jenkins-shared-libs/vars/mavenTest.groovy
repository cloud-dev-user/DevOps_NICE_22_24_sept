def call() {
    stage('Maven Test') {
        sh 'mvn test'
        junit '**/target/surefire-reports/*.xml'
    }
}
