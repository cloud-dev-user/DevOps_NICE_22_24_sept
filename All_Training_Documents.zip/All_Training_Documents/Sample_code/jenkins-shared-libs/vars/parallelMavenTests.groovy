def call(Map modules) {
    Map branches = [:]
    modules.each { moduleName, moduleDir ->
        branches[moduleName] = {
            dir(moduleDir) {
                sh 'mvn test'
                junit testResults: '**/target/surefire-reports/*.xml', allowEmptyResults: true
            }
        }
    }
    parallel branches
}