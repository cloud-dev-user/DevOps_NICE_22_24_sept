package com.example.tax;

public class TaxCalculator {
    public double calculateGST(double amount) {
        return amount * 0.18;
    }
}
