package com.example.core;

public class ForexConverter {
    public double inrToUsd(double inr) { return inr * 0.012; }
    public double usdToInr(double usd) { return usd / 0.012; }
}
